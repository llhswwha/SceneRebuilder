﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeshHelper
{
    /// <summary>
    /// 用一个单元模型，替换掉场景中的相同模型。
    /// </summary>
    /// <param name="oldObj"></param>
    /// <param name="prefab"></param>
    /// <returns></returns>
    public static GameObject ReplaceByPrefab(GameObject oldObj, GameObject prefab)
    {
        if (prefab == null) return null;
        GameObject newObj = GameObject.Instantiate(prefab);
        newObj.SetActive(true);
        newObj.name = oldObj.name + "_New";

        //newObj.transform.position = oldObj.transform.position;
        //newObj.transform.eulerAngles = oldObj.transform.eulerAngles;
        //newObj.transform.parent = oldObj.transform;
        newObj.transform.parent = oldObj.transform.parent;
        newObj.transform.localPosition = oldObj.transform.localPosition;
        newObj.transform.localScale = oldObj.transform.localScale;
        //newObj.transform.localEulerAngles = Vector3.zero;
        newObj.transform.localEulerAngles = oldObj.transform.localEulerAngles + new Vector3(0, 90, 90);

        //GameObject.Destroy(item.gameObject.transform);
#if UNITY_EDITOR
        if (oldObj.GetComponent<MeshNode>() == null)
        {
            oldObj.AddComponent<MeshNode>();
        }
        if (newObj.GetComponent<MeshNode>() == null)
        {
            newObj.AddComponent<MeshNode>();
        }
#endif
        return newObj;
    }

    public static IEnumerator ReplaceByPrefabEx(GameObject oldObj, GameObject prefab, string bufferKey1 = "", string bufferKey2 = "", bool isDestoryOriginal = true)
    {
        if (prefab == null)
        {
            yield break;
        }
        GameObject newObj = ReplaceByPrefab(oldObj, prefab);
        yield return RotateUntilMinDistanceEx(oldObj.transform, newObj.transform, bufferKey1, bufferKey2);
        if(isDestoryOriginal)
            GameObject.Destroy(oldObj.gameObject);
    }

    public static MeshRotateBuffer buffer = new MeshRotateBuffer();

    public static bool showLog = true;
    private static void DebugLog(string msg)
    {
        if(showLog)
            Debug.Log(msg);
    }

    public static IEnumerator RotateUntilMinDistanceEx(Transform oldObj, Transform newObj, string bufferKey1 = "",string bufferKey2="", YieldInstruction yieldInstruction = null)
    {
        //int rx = 0;
        //int ry = 0;
        //int rz = 0;

        DateTime start = DateTime.Now;
        Transform target = oldObj;
        float min = float.MaxValue;
        Vector3 v = Vector3.zero;
        int i = 0;
        {
            if (!string.IsNullOrEmpty(bufferKey1))
            {
                MeshRotateInfo info = buffer.Get(bufferKey1, bufferKey2, oldObj.localEulerAngles);
                if (info != null)
                {
                    newObj.localEulerAngles = info.V2;

                    DebugLog(string.Format("RotateUntilMinDistance 获取缓存信息:{0}", info));

                    //yield break;
                }
            }
        }

        {
            float distance = MeshHelper.GetVertexDistanceEx(target, newObj);
            if (minDistance > 0 && distance < minDistance)
            {
                DebugLog(string.Format("[{0}]RotateUntilMinDistance(成功) 用时:{1:F1}s，距离:{2},角度1:{3},角度2:{4}",
                    i, (DateTime.Now - start).TotalSeconds, distance, oldObj.localEulerAngles, newObj.localEulerAngles));
                //结束1:成功

                yield break;
            }
        }

        for (int rx = 0; rx < 4; rx++)
        {
            for (int ry = 0; ry < 4; ry++)
            {
                for (int rz = 0; rz < 4; rz++)
                {
                    i++;
                    newObj.localEulerAngles = new Vector3(90 * rx, 90 * ry, 90 * rz);
                    float distance = MeshHelper.GetVertexDistanceEx(target, newObj,string.Format("{0}/{1}",i,64));
                    if (distance > 0)
                    {
                        if (minDistance > 0 && distance < minDistance)
                        {
                            DebugLog(string.Format("[{0}]RotateUntilMinDistance(成功) 用时:{1:F1}s，距离:{2},角度1:{3},角度2:{4}",
                                i, (DateTime.Now - start).TotalSeconds, distance, oldObj.localEulerAngles, newObj.localEulerAngles));
                            //结束1:成功
                            if (!string.IsNullOrEmpty(bufferKey1))
                            {
                                buffer.Set(bufferKey1,bufferKey2, oldObj.localEulerAngles, newObj.localEulerAngles);
                            }
                            yield break;
                        }

                        if (distance < min)
                        {
                            min = distance;
                            v = newObj.localEulerAngles;
                        }
                        //继续
                        //DebugLog(string.Format("[{0}]RotateUntilMinDistance(继续) 用时:{1:F1}s，距离:{2},角度:{3}，最小距离:{4}",i, (DateTime.Now - start).TotalSeconds, distance, v, min));
                        //yield return new WaitForSeconds(0.5f);
                        //yield return new WaitForEndOfFrame();//17.2s / 64 = 0.269
                        //yield return null;//13.2s / 64 = 0.206s
                        //yield return new WaitForFixedUpdate();//4.8s / 64 = 0.075
                        yield return yieldInstruction;
                    }
                    else
                    {
                        //结束2:失败1
                        yield break;
                    }
                }
            }
        }

        {
            //结束3:失败2，没有结束1的情况下，走到这里也可以找出最合适的角度
            DebugLog(string.Format("RotateUntilMinDistance(成功) 用时:{0:F1}s，距离:{1},角度:{2}", (DateTime.Now - start).TotalSeconds, min, v));
            newObj.localEulerAngles = v;
        }
        //结束1:成功
        yield break;

    }


    public static IEnumerator RotateUntilMinDistance(Transform oldObj, Transform newObj, string bufferKey = "",float minDistance = 0.01f, YieldInstruction yieldInstruction=null)
    {
        //int rx = 0;
        //int ry = 0;
        //int rz = 0;

        DateTime start = DateTime.Now;
        Transform target = oldObj;
        float min = float.MaxValue;
        Vector3 v = Vector3.zero;
        int i = 0;
        {
            if (!string.IsNullOrEmpty(bufferKey))
            {
                MeshRotateInfo info=buffer.Get(bufferKey,"", oldObj.localEulerAngles);
                if (info != null)
                {
                    newObj.localEulerAngles = info.V2;

                    DebugLog(string.Format("RotateUntilMinDistance 获取缓存信息:{0}", info));
                }
            }
        }

        {
            float distance = MeshHelper.GetVertexDistance(target, newObj);
            if (minDistance > 0 && distance < minDistance)
            {
                DebugLog(string.Format("[{0}]RotateUntilMinDistance(成功) 用时:{1:F1}s，距离:{2},角度1:{3},角度2:{4}",
                    i, (DateTime.Now - start).TotalSeconds, distance, oldObj.localEulerAngles, newObj.localEulerAngles));
                //结束1:成功
               
                yield break;
            }
        }

        for(int rx = 0; rx < 4; rx++)
        {
            for (int ry = 0; ry < 4; ry++)
            {
                for (int rz = 0; rz < 4; rz++)
                {
                    i++;
                    newObj.localEulerAngles = new Vector3(90 * rx, 90 * ry, 90 * rz);
                    float distance = MeshHelper.GetVertexDistance(target, newObj);
                    if (distance > 0)
                    {
                        if (minDistance>0 && distance < minDistance)
                        {
                            DebugLog(string.Format("[{0}]RotateUntilMinDistance(成功) 用时:{1:F1}s，距离:{2},角度1:{3},角度2:{4}", 
                                i,(DateTime.Now - start).TotalSeconds, distance, oldObj.localEulerAngles,newObj.localEulerAngles));
                            //结束1:成功
                            if (!string.IsNullOrEmpty(bufferKey))
                            {
                                buffer.Set(bufferKey,"", oldObj.localEulerAngles, newObj.localEulerAngles);
                            }
                                yield break;
                        }

                        if (distance < min)
                        {
                            min = distance;
                            v = newObj.localEulerAngles;
                        }
                        //继续
                        //DebugLog(string.Format("[{0}]RotateUntilMinDistance(继续) 用时:{1:F1}s，距离:{2},角度:{3}，最小距离:{4}",i, (DateTime.Now - start).TotalSeconds, distance, v, min));
                        //yield return new WaitForSeconds(0.5f);
                        //yield return new WaitForEndOfFrame();//17.2s / 64 = 0.269
                        //yield return null;//13.2s / 64 = 0.206s
                        //yield return new WaitForFixedUpdate();//4.8s / 64 = 0.075
                        yield return yieldInstruction;
                    }
                    else
                    {
                        //结束2:失败1
                        yield break;
                    }
                }
            }
        }

        {
            //结束3:失败2，没有结束1的情况下，走到这里也可以找出最合适的角度
            DebugLog(string.Format("RotateUntilMinDistance(成功) 用时:{0:F1}s，距离:{1},角度:{2}", (DateTime.Now - start).TotalSeconds, min, v));
            newObj.localEulerAngles =v;
        }
        //结束1:成功
        yield break;

    }

    /// <summary>
    /// 计算两个相同模型在某一个角度时的“点的距离”，以便判断当前的角度是否合适
    /// </summary>
    /// <param name="t1"></param>
    /// <param name="t2"></param>
    /// <returns></returns>
    public static float GetVertexDistance(Transform t1, Transform t2)
    {
        MeshFilter mf1 = t1.GetComponent<MeshFilter>();
        MeshFilter mf2 = t2.GetComponent<MeshFilter>();
        if (mf1 == null || mf2 == null)
        {
            return -1;
        }
        else
        {
            //return GetVertexDistance(mf1.sharedMesh, mf2.sharedMesh);
            Mesh mesh1 = mf1.sharedMesh;
            Mesh mesh2 = mf2.sharedMesh;
            if (mesh1.vertexCount != mesh2.vertexCount)
            {
                return float.MaxValue;
            }
            else
            {
                float distance = 0;
                for (int i = 0; i < mesh1.vertexCount; i++)
                {
                    Vector3 p1 = mesh1.vertices[i];
                    Vector3 p11 = t1.TransformPoint(p1);
                    Vector3 p2 = mesh2.vertices[i];
                    Vector3 p22 = t2.TransformPoint(p2);

                    float d = Vector3.Distance(p11, p22);
                    distance += d;
                }
                return distance;
            }
        }
    }

    public static float zero = 0.00001f;
    public static int zeroMax = 100;

    public static int maxDistance = 5;
    public static int minDistance = 5;

    public static float GetVertexDistanceEx(Transform t1, Transform t2, string progress = "")
    {
        DateTime start = DateTime.Now;

        MeshFilter mf1 = t1.GetComponent<MeshFilter>();
        MeshFilter mf2 = t2.GetComponent<MeshFilter>();
        if (mf1 == null || mf2 == null)
        {
            return -1;
        }
        else
        {
            //return GetVertexDistance(mf1.sharedMesh, mf2.sharedMesh);
            Mesh mesh1 = mf1.sharedMesh;
            Mesh mesh2 = mf2.sharedMesh;
            if (mesh1.vertexCount != mesh2.vertexCount)
            {
                return float.MaxValue;
            }
            else
            {
                float distance = 0;
                List<Vector3> points1 = GetWorldVertexes(mesh1, t1);
                List<Vector3> points2 = GetWorldVertexes(mesh2, t2);
                //List<float> disList = new List<float>();
                int zeroCount = 0;
                int i = 0;
                for (; i < points1.Count; i++)
                {
                    Vector3 p1 = points1[i];
                    Vector3 p2 = GetMinDistancePoint(p1, points2);
                    float d = Vector3.Distance(p1, p2);
                    if (d < zero)
                    {
                        zeroCount++;
                        if (zeroCount > zeroMax)//没必要计算完，大概100个都位置相同的话，就是可以的了。
                        {
                            //return distance;//不能返回0哦
                            break;
                        }
                        else
                        {

                        }
                    }
                    //disList.Add(d);
                    distance += d;

                    if (distance > maxDistance)//没必要计算完，整体距离很大的话，就是已经是不行的了
                    {
                        break;
                    }
                }

                //disList.Sort();
                //disList.Reverse();

                DebugLog(string.Format("GetVertexDistanceEx 用时:{0:F2}s，距离:{1},序号:{2}，物体:{3}，进度:{4}",(DateTime.Now - start).TotalSeconds, distance,i,t1.name, progress));

                return distance;
            }
        }


    }

    private static Vector3 GetMinDistancePoint(Vector3 p1, List<Vector3> points)
    {
        //DateTime start = DateTime.Now;

        float distance = float.MaxValue;
        Vector3 result = Vector3.zero;
        int index = 0;
        for (int i = 0; i < points.Count; i++)
        {
            Vector3 p2 = points[i];
            float dis = Vector3.Distance(p1, p2);
            if (dis < distance)
            {
                distance = dis;
                result = p2;
                index = i;
            }
        }

        //if(distance<zero)
        //    DebugLog(string.Format("GetMinDistancePoint 用时:{0}s，距离:{1}，序号:{2}", (DateTime.Now - start).TotalSeconds, distance, index));
        return result;
    }

    private static List<Vector3> GetWorldVertexes(Mesh mesh1, Transform t1){
        List<Vector3> points1 = new List<Vector3>();
        for (int i = 0; i < mesh1.vertexCount; i++)
        {
            Vector3 p1 = mesh1.vertices[i];
            Vector3 p11 = t1.TransformPoint(p1);
            points1.Add(p11);
        }
        return points1;
    }



    public static float GetVertexDistance(Mesh mesh1, Mesh mesh2)
    {
        if (mesh1.vertexCount != mesh2.vertexCount)
        {
            return float.MaxValue;
        }
        else
        {
            float distance = 0;
            for (int i = 0; i < mesh1.vertexCount; i++)
            {
                Vector3 p1 = mesh1.vertices[i];
                
                Vector3 p2 = mesh2.vertices[i];
                float d = Vector3.Distance(p1, p2);
                distance += d;
            }
            return distance;
        }
    }
}
