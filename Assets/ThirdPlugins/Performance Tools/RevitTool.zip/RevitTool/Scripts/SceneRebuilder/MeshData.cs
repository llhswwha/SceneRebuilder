﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class MeshData 
{
    public Mesh mesh;

    public int triangleCount = 0;

    public int vertexCount = 0;

    public int vertexBufferCount = 0;

    public int vertexAttributeCount = 0;

    public int subMeshCount = 0;

    //public Vector3[] vertices;

    //public Vector3[] normals;

    //public Vector4[] tangents;

    //public Vector2[] uv;

    //public Color[] colors;

    //public Color32[] colors32;

    //public Vector2[] uv2;

    //public Vector2[] uv3;

    public MeshInfo Info = new MeshInfo();

    private GameObject _obj;

    public override string ToString()
    {
        if (_obj == null) return base.ToString();
        return "MeshData:" + _obj.name;
    }

    public MeshData(GameObject obj)
    {
        _obj = obj;
        MeshFilter msFilter = obj.GetComponent<MeshFilter>();
        try
        {
           
            if (msFilter != null)
            {
                Mesh ms = msFilter.sharedMesh;
                if (ms == null)
                {
                    Debug.LogError("MeshData.cotr, ms == null," + msFilter);
                    return;
                }
                this.mesh = ms;
                triangleCount = ms.triangles.Length;
                vertexCount = ms.vertexCount;
                vertexBufferCount = ms.vertexBufferCount;
                vertexAttributeCount = ms.vertexAttributeCount;
                subMeshCount = ms.subMeshCount;

                //uv = ms.uv;
                //uv2 = ms.uv2;
                //uv3 = ms.uv3;

                //vertices = ms.vertices;
                //normals = ms.normals;
                //tangents = ms.tangents;
                //colors = ms.colors;
                //colors32 = ms.colors32;

                Info.m_Mesh = ms;
                Info.Update();
            }
        }
        catch (Exception ex)
        {
            Debug.LogError("MeshData.cotr,"+ msFilter + ","+ex);
        }


    }

    public MeshData()
    {

    }

    public void Add(MeshData info)
    {
        if (info != null)
        {
            Mesh ms = info.mesh;
            if (ms != null)
            {
                triangleCount += ms.triangles.Length;
                vertexCount += ms.vertexCount;
                vertexBufferCount += ms.vertexBufferCount;
                vertexAttributeCount += ms.vertexAttributeCount;
            }
            else
            {
                Debug.LogWarning("MeshData.Add ms==null:"+info);
            }
        }
        else
        {
            Debug.LogWarning("MeshData.Add info==null");
        }
        

    }

    internal bool IsSameMesh(MeshData info)
    {
        if (this.Info != null && info.Info != null)
        {
            return this.Info.m_meshFeature == info.Info.m_meshFeature;
        }
        else
        {
            bool r1 = triangleCount == info.triangleCount && vertexCount == info.vertexCount && vertexBufferCount == info.vertexBufferCount && vertexAttributeCount == info.vertexAttributeCount;
            return r1;
        }

    }
}
