﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeshNode : MonoBehaviour,IComparable<MeshNode>
{
    public string MeshTypeName = "";

    public List<MeshType> TypesList = new List<MeshType>();

    public MeshData meshData;

    public TransformData transformData;

    public int GetVertexCount()
    {
        if (meshData != null)
        {
            return meshData.vertexCount;
        }
        return 0;
    }

    public string GetMeshKey1()
    {
        if (meshData != null)
        {
            if (meshData.Info != null)
            {
                return meshData.Info.m_meshFeature;
            }
        }
        return MeshTypeName;
    }

    public string GetMeshKey2()
    {
        if (meshData != null)
        {
            if (meshData.Info != null)
            {
                return meshData.Info.m_vertexFeature;
            }
        }
        return MeshTypeName;
    }

    public int VertexCount = 0;

    //public MeshInfo Info = new MeshInfo();

    public List<MeshNode> subMeshes = new List<MeshNode>();

    public MeshNode parentMesh = null;

    public MeshData totalMesh = null;

    private  void AddSubMeshInfo(MeshNode mn)
    {
        meshData.Add(mn.meshData);
        AddType(mn);
        if (parentMesh != null)
        {
            parentMesh.AddSubMeshInfo(mn);
        }
        VertexCount += mn.GetVertexCount();
    }

    // Start is called before the first frame update

    public bool initAllChildren = true;

    public void InitInfo()
    {
        if (gameObject.isStatic) return;
        if (meshData == null || meshData.vertexCount==0)
        {
            //GameObjectUtility.SetStaticEditorFlags.
            
            
            meshData = new MeshData(gameObject);

            //if (filter != null)
            //{
            //    Info.m_Mesh = filter.mesh;
            //    Info.Update();
            //}

            VertexCount += meshData.vertexCount;
        }

        //if (transformData == null)
        {
            transformData = new TransformData(transform);
        }

    }

    [ContextMenu("RefreshInfo")]
    public void RefreshInfo()
    {
        meshData = null;
        transformData = null;
        InitInfo();
    }

    void Start()
    {
        Init();
    }

    public bool isInited = false;

    public void Init()
    {
        if (isInited == true) return;
        isInited = true;

        MeshTypeName = MeshType.GetTypeName(gameObject.name);

        if (gameObject.isStatic)
        {
            Debug.LogError("IsStatic:" + gameObject);
            return;
        }

        InitInfo();

        if (initAllChildren)
        {
            subMeshes.Clear();
            for (int i = 0; i < transform.childCount; i++)
            {
                var child = transform.GetChild(i).gameObject;
                MeshNode subMesh = child.GetComponent<MeshNode>();
                if (subMesh == null)
                {
                    subMesh = child.AddComponent<MeshNode>();
                    subMesh.Init();
                }
                AddSubMesh(subMesh);
                subMesh.parentMesh = this;
                subMesh.AddInfoToParent();
            }
            subMeshes.Sort();
            TypesList.Sort();

            int allCount = 0;
            foreach (MeshType meshType in TypesList)
            {
                allCount += meshType.VertexCount;
            }

            if(allCount>0)
                foreach (MeshType meshType in TypesList)
                {
                    meshType.Percent = meshType.VertexCount * 100f / allCount;
                }
        }
    }

    public void AddInfoToParent()
    {
        if (parentMesh != null)
        {
            parentMesh.AddSubMeshInfo(this);
        }
    }

    public void AddSubMesh(MeshNode mn)
    {
        if (!subMeshes.Contains(mn))
        {
            subMeshes.Add(mn);
            AddType(mn);
        }
        
    }

    public void AddType(MeshNode mn)
    {
        MeshType meshType = TypesList.Find(i => i.TypeName == mn.MeshTypeName);
        if (meshType == null)
        {
            meshType = new MeshType();
            meshType.TypeName = mn.MeshTypeName;
            TypesList.Add(meshType);
        }
        meshType.AddItem(mn);
    }

    [ContextMenu("SortSubMeshes")]
    public void SortSubMeshes()
    {
        subMeshes.Sort();
    }

    internal bool IsSameMesh(MeshNode node)
    {
        return this.meshData.IsSameMesh(node.meshData);
    }

    private float pScale = 0.05f;

    public List<GameObject> vertextObjects = new List<GameObject>();

    [ContextMenu("ShowVertexes")]
    public void ShowVertexes()
    {
        if (meshData.vertexCount == 0)
        {
            isInited = false;
            Init();
        }
        
        Debug.Log("ShowVertexes:"+ meshData.vertexCount);
        ClearVertexes();
        for (int i = 0; i < meshData.vertexCount; i++)
        {
            Vector3 p = meshData.mesh.vertices[i];
            GameObject go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            //go.transform.parent = this.transform;
            //go.transform.localScale = new Vector3(pScale, pScale, pScale);
            //go.transform.localPosition = p;

            //go.transform.parent = this.transform;
            go.transform.localScale = new Vector3(pScale, pScale, pScale);
            go.transform.position = transform.TransformPoint(p);
            go.name = string.Format("[{0}]{1}", i, go.transform.position);
            go.transform.parent = this.transform;

            vertextObjects.Add(go);

            TransformNode tn=go.AddComponent<TransformNode>();
            tn.Init();
        }
    }

    [ContextMenu("ClearVertexes")]
    public void ClearVertexes()
    {
        foreach (var item in vertextObjects)
        {
            GameObject.DestroyImmediate(item);
        }
        vertextObjects.Clear();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public int CompareTo(MeshNode other)
    {
        return other.GetVertexCount().CompareTo(this.GetVertexCount());
    }
}
