﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//[RequireComponent(typeof(LODGroup))]
public class LODGroupInfo : MonoBehaviour
{
    public LODGroup LODGroup;

    public List<LODInfo> LodInfos = new List<LODInfo>();

    public int lodCount;

    // Start is called before the first frame update
    void Start()
    {
        LODGroup = gameObject.GetComponent<LODGroup>();
        LOD[] lods = LODGroup.GetLODs();
        foreach (var lod in lods)
        {
            LODInfo lodInfo = new LODInfo(lod);
            LodInfos.Add(lodInfo);
        }
        lodCount = LODGroup.lodCount;
    }

    [ContextMenu("SetLODs")]
    void SetLODs()
    {
        List<LOD> lods = new List<LOD>();
        foreach (var lodInfo in LodInfos)
        {
            LOD lod = lodInfo.GetLOD();
            lods.Add(lod);
        }
        LODGroup.SetLODs(lods.ToArray());
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
