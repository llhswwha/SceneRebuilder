﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevitTools.Infos
{
    public enum ElementGroupType
    {
        Type,Family,Catagory
    }
}
