﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DataA : ScriptableObject
{
    public int a = 1;
    public string b = "b";
}
