﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[DisallowMultipleComponent]
public class MyStopConvertToEntity : MonoBehaviour
{
    
}
