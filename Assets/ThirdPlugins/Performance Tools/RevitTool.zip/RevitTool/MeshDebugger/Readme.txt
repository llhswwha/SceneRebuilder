﻿Thanks for using my plugin!

MeshDebugger - 0.7.0 - Shared with ❤ - © Wildan Mubarok 2018 under MIT License.
To begin inspecting a mesh, just navigate to Window -> Mesh Debugger in menu bar then select an object.
See https://github.com/willnode/MeshDebugger/blob/master/INSTRUCTIONS.md for more instructions about using this plugin.
