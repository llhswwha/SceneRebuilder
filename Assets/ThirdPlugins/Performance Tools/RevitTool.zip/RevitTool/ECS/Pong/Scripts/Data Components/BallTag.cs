﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct BallTag : IComponentData
{ }
