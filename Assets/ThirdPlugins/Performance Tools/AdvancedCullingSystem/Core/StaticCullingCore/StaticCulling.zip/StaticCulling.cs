﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;

namespace AdvancedCullingSystem.StaticCullingCore
{
    public class StaticCulling : MonoBehaviour
    {
        public static void Clear()
        {
            foreach (var culling in FindObjectsOfType<StaticCulling>())
                DestroyImmediate(culling.gameObject);

            foreach (var tree in FindObjectsOfType<BinaryTree>())
                DestroyImmediate(tree.gameObject);
        }


        public static StaticCulling Instance { get; private set; }

        [SerializeField]
        [HideInInspector]
        private MeshRenderer[] _renderers;

        [SerializeField]
        //[HideInInspector] //cww delete
        private BinaryTree[] _trees;

        [SerializeField]
        private List<Camera> _cameras;

        [Header("Editor only")]

        [SerializeField]
        public bool _enableFrustum;

        [SerializeField]
        private bool _drawCullingArea;

        [SerializeField]
        public StaticCullingMaster cullingMaster;


        public static StaticCulling Create(MeshRenderer[] renderers, BinaryTree[] trees, Camera[] cameras = null)
        {
            StaticCulling staticCulling = new GameObject("Static Culling").AddComponent<StaticCulling>();

            staticCulling._renderers = renderers;
            staticCulling._trees = trees;
            //staticCulling._drawCullingArea = true;//cww add 避免每次都要手动去选上
            staticCulling._enableFrustum = true;

            if (cameras != null)
            {
                staticCulling._cameras = new List<Camera>();

                for (int i = 0; i < cameras.Length; i++)
                    staticCulling.AddCamera(cameras[i]);
            }

            return staticCulling;
        }


        private void Awake()
        {
            Instance = this;
        }

        private void Start()
        {
            CheckCameras();

            SelectedCount = _renderers.Length;

            if (renderDict.Count == 0)
            {
                renderDict.Clear();
                foreach (var render in FindObjectsOfType<MeshRenderer>())
                {
                    renderDict.Add(render.GetInstanceID(), render);
                }

                AllCount = renderDict.Count;
            }
        }

        Dictionary<int, MeshRenderer> renderDict = new Dictionary<int, MeshRenderer>();

        public bool EnableCulling = true;//cww_add

        private List<Renderer> visibleRenderers = new List<Renderer>();

        public int VisibleCount = 0;

        public int SelectedCount = 0;

        public int AllCount = 0;

        public double UpdateTime = 0;

        private void UpdateRenderersVisible()
        {
            DateTime start = DateTime.Now;
            try
            {
                if (EnableCulling == false) return;
                DisableRenderers();//隐藏所有相关物体
                int i = 0;
                while (i < _cameras.Count)
                {
                    if (_cameras[i] == null)
                    {
                        Debug.Log("StaticCulling::looks like camera was destroyed");
                        _cameras.RemoveAt(i);
                        if (!CheckCameras())
                            return;
                        continue;
                    }
                    bool insideArea = false;
                    Vector3 pos = _cameras[i].transform.position;//摄像头坐标
                    for (int c = 0; c < _trees.Length; c++)
                    {
                        var tree = _trees[c];
                        if (new Bounds(tree.rootNode.center, tree.rootNode.size).Contains(pos))//找到包含该坐标的Tree
                        {
                            var node = tree.GetNode(pos);//根据坐标再找到找到TreeNode(Cell);
                            EnableRenderers(_cameras[i], node.visibleRenderers);//显示该Cell内可见的物体
                            insideArea = true;
                            break;
                        }
                    }
                    if (!insideArea)
                    {
                        EnableRenderers();//不在采样区域内时则显示所有的模型
                        return;
                    }
                    i++;
                }
                VisibleCount = visibleRenderers.Count;
            }
            catch (System.Exception ex)
            {
                Debug.Log("StaticCulling::get exception");
                Debug.Log("Cause : " + ex.Message + " " + ex.StackTrace);
                Debug.Log("Please write about it on e-mail(andre-orsk@yandex.ru) and I will help You");
                Debug.Log("-----------------------------------");
                Disable();
            }

            UpdateTime = (DateTime.Now - start).TotalMilliseconds;
        }

        private void Update()
        {
            UpdateRenderersVisible();
        }

        private void OnDrawGizmos()
        {
            //Debug.Log("OnDrawGizmos");
            if (!_drawCullingArea || _trees == null || _trees.Length == 0)
                return;

            //Debug.Log("OnDrawGizmos2:"+_trees.Length);
            foreach (var tree in _trees)
                BinaryTreeUtil.DrawGizmos(tree, Color.blue);
        }

        private void OnDrawGizmosSelected()
        {
            //Debug.Log("OnDrawGizmosSelected");
            if (_drawCullingArea || _trees == null || _trees.Length == 0)
                return;

            //Debug.Log("OnDrawGizmosSelected2:"+_trees.Length);
            Gizmos.color = Color.blue;
            foreach (var tree in _trees)
            {
                Gizmos.DrawWireCube(tree.rootNode.center, tree.rootNode.size*2);
            }
        }


        private bool CheckCameras()
        {
            if (_cameras == null || _cameras.Count == 0)
            {
                Debug.Log("StaticCulling::no cameras assigned");

                Disable();

                return false;
            }

            return true;
        }

        [ContextMenu("DisableRenderers")]
        private void DisableRenderers()
        {
            for (int i = 0; i < _renderers.Length; i++)
                _renderers[i].HideRenderer();//只显示阴影，不显示模型

            visibleRenderers.Clear();
        }

        [ContextMenu("EnableRenderers")]
        private void EnableRenderers()
        {
            for (int i = 0; i < _renderers.Length; i++)
            {
                _renderers[i].ShowRenderer();//显示阴影和模型
                
            }

            VisibleCount = _renderers.Length;
        }

        private void EnableRenderers(Camera camera, List<MeshRenderer> renderers)
        {
#if UNITY_EDITOR
            Plane[] planes = null;
            if (_enableFrustum)
                planes = GeometryUtility.CalculateFrustumPlanes(camera);//视椎体剔除

            //从可见模型列表中剔除视锥体外的模型，只显示视锥体内的模型
            for (int i = 0; i < renderers.Count; i++)
                if (!_enableFrustum || GeometryUtility.TestPlanesAABB(planes, renderers[i].bounds))
                {
                    renderers[i].ShowRenderer();
                    if (!visibleRenderers.Contains(_renderers[i]))
                    {
                        visibleRenderers.Add(_renderers[i]);
                    }
                }
#else
            for (int i = 0; i < renderers.Count; i++)
            {
                renderers[i].ShowRenderer();
                if(!visibleRenderers.Contains(_renderers[i]))
                {
                    visibleRenderers.Add(_renderers[i]);
                }
            }
#endif
        }


        public void AddCamera(Camera camera)
        {
            if (!_cameras.Contains(camera))
                _cameras.Add(camera);

            if (!enabled)
                Enable();
        }

        public void RemoveCamera(Camera camera)
        {
            if (_cameras.Contains(camera))
                _cameras.Remove(camera);

            CheckCameras();
        }

        public void Enable()
        {
            enabled = true;

            CheckCameras();
        }

        public void Disable()
        {
            EnableRenderers();

            enabled = false;
        }
    }
}