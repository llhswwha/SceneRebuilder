﻿
// Rigid Transform implementation using explanation in http://nghiaho.com/?page_id=671
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Accord.Math;
using Accord;

public class AcRigidTransform : MonoBehaviour
{
    // Initial objects   
    public GameObject CubeReg;
    public GameObject SphereReg;
    public GameObject CylinderReg;

    // Transformed objects
    public GameObject CubeTransformed;
    public GameObject SphereTransformed;
    public GameObject CylinderTransformed;
    
    // object used as a 4th point to test Transformation Matrix
    public GameObject TestObject;

    public GameObject TestObject2;

    private AcRTTransform rTTransform;

        // Function to apply transformation to 4th point/object
    [ContextMenu("ApplyTransformation")]
    public void ApplyTransformation()
    {
        if(rTTransform==null){
            rTTransform=new AcRTTransform();
            rTTransform.InitTarget(TestObject.transform);
        }
        var p01=TestObject.transform.position;
        var p02=TestObject.transform.position;

        rTTransform.ApplyTransformation(CubeReg,SphereReg,CylinderReg,CubeTransformed,SphereTransformed,CylinderTransformed);

        var p03=rTTransform.ApplyPoint(p01);

        var dis=UnityEngine.Vector3.Distance(p03,p02);

        p01.PrintVector3("P01");
        p02.PrintVector3("P02");
        p03.PrintVector3("P03");

        Debug.Log(dis);
    }
}

public class AcRTTransform  {

    // variables used for RigidTransform
    private Matrix3x3 H;
    private Matrix3x3 U;
    private Accord.Math.Vector3 E;
    private Matrix3x3 V;
    private Matrix3x3 R;
    private Accord.Math.Vector3 centroidA;
    private Accord.Math.Vector3 centroidB;
    private Accord.Math.Vector4 x;
    private UnityEngine.Matrix4x4 TransformationMatrix;
    private Accord.Math.Vector3 Translation;

    // Saving initial position and rotation to apply transformation in Update()
    private UnityEngine.Vector3 InitPosition;
    private Quaternion InitQT;

    private Transform target;

    public void InitTarget (Transform target) {
        this.target=target;
        InitPosition = target.position;
        InitQT = target.rotation;        
    }

public void ApplyTransformation(GameObject cube1,GameObject sphere1,GameObject cylinder1,GameObject cube2,GameObject sphere2,GameObject cylinder2)
{
        // Accord.Math.Vector3 p01=AcRTTransform.UnitytoAccord(cube1.transform.position);
        // Accord.Math.Vector3 p02=AcRTTransform.UnitytoAccord(sphere1.transform.position);
        // Accord.Math.Vector3 p03=AcRTTransform.UnitytoAccord(cylinder1.transform.position);
        // Accord.Math.Vector3 p11=AcRTTransform.UnitytoAccord(cube2.transform.position);
        // Accord.Math.Vector3 p12=AcRTTransform.UnitytoAccord(sphere2.transform.position);
        // Accord.Math.Vector3 p13=AcRTTransform.UnitytoAccord(cylinder2.transform.position);

        ApplyTransformation(cube1.transform.position,sphere1.transform.position,cylinder1.transform.position
        ,cube2.transform.position,sphere2.transform.position,cylinder2.transform.position);
}

// public void ApplyTransformation(UnityEngine.Vector3 p01e,UnityEngine.Vector3 p02e,UnityEngine.Vector3 p03e,UnityEngine.Vector3 p11e,UnityEngine.Vector3 p12e,UnityEngine.Vector3 p13e)
// {
        
//         TransformationMatrix = AcRTTransform.ApplyTransformation(p01e,p02e,p03e,p11e,p12e,p13e);
//         Debug.Log(TransformationMatrix);

//         InitPosition.PrintVector3("p01");
//         TestObject2.transform.position.PrintVector3("p02");

//         var p1=  TransformationMatrix.MultiplyPoint(InitPosition);
//         p1.PrintVector3("p1");//应该和p02是相同的。
        
//         // TestObject.transform.position = TransformationMatrix.MultiplyPoint(InitPosition);
//         // TestObject.transform.rotation = Quaternion.LookRotation(TransformationMatrix.GetColumn(1), TransformationMatrix.GetColumn(2))* InitQT;
//     }

    public UnityEngine.Vector3 ApplyPoint(UnityEngine.Vector3 p1)
    {
                // InitPosition.PrintVector3("p01");
        // InitPosition1.PrintVector3("p02");

        return TransformationMatrix.MultiplyPoint(InitPosition);
        // p1.PrintVector3("p1");//应该和p02是相同的。，发现可能第一次不同，第二次就相同的。
    }

        public void ApplyTransform()
    {
                target.position = TransformationMatrix.MultiplyPoint(InitPosition);
        target.rotation = Quaternion.LookRotation(TransformationMatrix.GetColumn(1), TransformationMatrix.GetColumn(2))* InitQT;
    }

    public void ApplyTransformation(UnityEngine.Vector3 p01e,UnityEngine.Vector3 p02e,UnityEngine.Vector3 p03e,UnityEngine.Vector3 p11e,UnityEngine.Vector3 p12e,UnityEngine.Vector3 p13e)
{
        Accord.Math.Vector3 p01=AcExtension.UnitytoAccord(p01e);
        Accord.Math.Vector3 p02=AcExtension.UnitytoAccord(p02e);
        Accord.Math.Vector3 p03=AcExtension.UnitytoAccord(p03e);
        Accord.Math.Vector3 p11=AcExtension.UnitytoAccord(p11e);
        Accord.Math.Vector3 p12=AcExtension.UnitytoAccord(p12e);
        Accord.Math.Vector3 p13=AcExtension.UnitytoAccord(p13e);

        //Calculating Centroids from both coordinate system
        centroidA = (p01 + p02 + p03) / 3;
        centroidB = (p11 + p12 + p13) / 3;
        Debug.Log("Centroid A is" + centroidA + " Centroid B is" + centroidB);

        // Calculating Covariance Matrix
        H = AcExtension.CovarianceMatrixStep(p01 - centroidA, p11 - centroidB)
            + AcExtension.CovarianceMatrixStep(p02 - centroidA, p12 - centroidB)
            + AcExtension.CovarianceMatrixStep(p03 - centroidA, p13 - centroidB);

        H.SVD(out U, out E, out V);
        R = V * U.Transpose();        
        
        // var InitPosition = TestObject.transform.position;
        // var InitQT = TestObject.transform.rotation;  

        // var InitPosition1=TestObject2.transform.position;

        Debug.Log("Determinant is" + R.Determinant);
        //special reflection case
        if(R.Determinant<0)
            {
                V.V02 = (-V.V02);
                V.V12 = (-V.V12);
                V.V22 = (-V.V22);
                R = V * U.Transpose();
                Debug.LogWarning("Reflection case");
            }
        
        Translation = AcExtension.NegativeMatrix(R) * centroidA + centroidB;
        Debug.Log("Translation is" + Translation);
        TransformationMatrix = AcExtension.AccordToUnityMatrix(TransformationMatrix, R, Translation);
        Debug.Log(TransformationMatrix);

        return;

        // InitPosition.PrintVector3("p01");
        // InitPosition1.PrintVector3("p02");

        // var p1=  TransformationMatrix.MultiplyPoint(InitPosition);
        // p1.PrintVector3("p1");//应该和p02是相同的。，发现可能第一次不同，第二次就相同的。
        
        // // Transformaiton Matrix for Unity
        // TransformationMatrix.SetTRS(AcRTTransform.AccordtoUnity(Translation), Quaternion.LookRotation(TransformationMatrix.GetColumn(1),
        //      TransformationMatrix.GetColumn(2)), UnityEngine.Vector3.one);
        // Debug.Log(TransformationMatrix);

        // var p2=  TransformationMatrix.MultiplyPoint(InitPosition);
        // p2.PrintVector3("p2");

        // 转换物体
        // // Applying Translation and rotation to 4th point/object
        // TestObject.transform.position = TransformationMatrix.MultiplyPoint(InitPosition);
        // TestObject.transform.rotation = Quaternion.LookRotation(TransformationMatrix.GetColumn(1), TransformationMatrix.GetColumn(2))* InitQT;
    }


    // public void ApplyTransformation(GameObject cube1,GameObject sphere1,GameObject cylinder1,GameObject cube2,GameObject sphere2,GameObject cylinder2)
    // {
    //     //Accord.Math.Vector3 p01=cube1.transform.position;

    //     //Calculating Centroids from both coordinate system
    //     centroidA = (AcRTTransform.UnitytoAccord(cube1.transform.position) + AcRTTransform.UnitytoAccord(sphere1.transform.position)
    //               + AcRTTransform.UnitytoAccord(cylinder1.transform.position)) / 3;
    //     centroidB = (AcRTTransform.UnitytoAccord(cube2.transform.position) + AcRTTransform.UnitytoAccord(sphere2.transform.position)
    //               + AcRTTransform.UnitytoAccord(cylinder2.transform.position)) / 3;
    //     Debug.Log("Centroid A is" + centroidA + " Centroid B is" + centroidB);

    //     // Calculating Covariance Matrix
    //     H = AcRTTransform.CovarianceMatrixStep(AcRTTransform.UnitytoAccord(cube1.transform.position) - centroidA, AcRTTransform.UnitytoAccord(cube2.transform.position) - centroidB)
    //         + AcRTTransform.CovarianceMatrixStep(AcRTTransform.UnitytoAccord(sphere1.transform.position) - centroidA, AcRTTransform.UnitytoAccord(sphere2.transform.position) - centroidB)
    //         + AcRTTransform.CovarianceMatrixStep(AcRTTransform.UnitytoAccord(cylinder1.transform.position) - centroidA, AcRTTransform.UnitytoAccord(cylinder2.transform.position) - centroidB);

    //     H.SVD(out U, out E, out V);
    //     R = V * U.Transpose();        
        
    //     InitPosition = TestObject.transform.position;
    //     InitQT = TestObject.transform.rotation;  

    //     var InitPosition1=TestObject2.transform.position;

    //     Debug.Log("Determinant is" + R.Determinant);
    //     //special reflection case
    //     if(R.Determinant<0)
    //         {
    //             V.V02 = (-V.V02);
    //             V.V12 = (-V.V12);
    //             V.V22 = (-V.V22);
    //             R = V * U.Transpose();
    //             Debug.LogWarning("Reflection case");
    //         }
        
    //     Translation = AcRTTransform.NegativeMatrix(R) * centroidA + centroidB;
    //     Debug.Log("Translation is" + Translation);
    //     TransformationMatrix = AcRTTransform.AccordToUnityMatrix(TransformationMatrix, R, Translation);
    //     Debug.Log(TransformationMatrix);

    //     InitPosition.PrintVector3("p01");
    //     InitPosition1.PrintVector3("p02");

    //     var p1=  TransformationMatrix.MultiplyPoint(InitPosition);
    //     p1.PrintVector3("p1");//应该和p02是相同的。
        
    //     // Transformaiton Matrix for Unity
    //     TransformationMatrix.SetTRS(AcRTTransform.AccordtoUnity(Translation), Quaternion.LookRotation(TransformationMatrix.GetColumn(1),
    //          TransformationMatrix.GetColumn(2)), UnityEngine.Vector3.one);
    //     Debug.Log(TransformationMatrix);

    //     var p2=  TransformationMatrix.MultiplyPoint(InitPosition);
    //     p2.PrintVector3("p2");

    //     // // Applying Translation and rotation to 4th point/object
    //     // TestObject.transform.position = TransformationMatrix.MultiplyPoint(InitPosition);
    //     // TestObject.transform.rotation = Quaternion.LookRotation(TransformationMatrix.GetColumn(1), TransformationMatrix.GetColumn(2))* InitQT;

    // }


    // // Update is called once per frame
    // void Update () {           
    //        ApplyTransformation();        
    // }
}

public static class AcExtension
{
    // Calculation of covariance matrix H
    public static Matrix3x3 CovarianceMatrixStep( Accord.Math.Vector3 difSetA, Accord.Math.Vector3 difSetB )
    {
        Matrix3x3 M;
        M.V00 = difSetA.X * difSetB.X;
        M.V01 = difSetA.X * difSetB.Y;
        M.V02 = difSetA.X * difSetB.Z;

        M.V10 = difSetA.Y * difSetB.X;
        M.V11 = difSetA.Y * difSetB.Y;
        M.V12 = difSetA.Y * difSetB.Z;

        M.V20 = difSetA.Z * difSetB.X;
        M.V21 = difSetA.Z * difSetB.Y;
        M.V22 = difSetA.Z * difSetB.Z;


        return M;
    }

    // Converting Unity.Vector3 to Accord.Vector3
    public static Accord.Math.Vector3 UnitytoAccord( UnityEngine.Vector3 pos )
    {
        Accord.Math.Vector3 posTransformed = new Accord.Math.Vector3();
        posTransformed.X = pos.x;
        posTransformed.Y = pos.y;
        posTransformed.Z = pos.z;

        return posTransformed;
    }
    // Converting  Accord.Vector3 to Unity.Vector3 
    public static UnityEngine.Vector3 AccordtoUnity(Accord.Math.Vector3 pos)
    {
        UnityEngine.Vector3 posTransformed = new UnityEngine.Vector3();
        posTransformed.x = pos.X;
        posTransformed.y = pos.Y;
        posTransformed.z = pos.Z;

        return posTransformed;
    }
    public static Matrix3x3 ZeroMatrix(Matrix3x3 m)
    {
        m.V00 = 0;
        m.V01 = 0;
        m.V02 = 0;
        m.V10 = 0;
        m.V11 = 0;
        m.V12 = 0;
        m.V20 = 0;
        m.V21 = 0;
        m.V22 = 0;

        return m;
    }
    public static Matrix3x3 NegativeMatrix(Matrix3x3 m)
    {
        m.V00 *= (-1);
        m.V01 *= (-1);
        m.V02 *= (-1);
        m.V10 *= (-1);
        m.V11 *= (-1);
        m.V12 *= (-1);
        m.V20 *= (-1);
        m.V21 *= (-1);
        m.V22 *= (-1);

        return m;
    }

    // Creating Unity Transformation matrix using 3x3 Rotation matrix and translation vector acquired from RigidTransform
    public static UnityEngine.Matrix4x4 AccordToUnityMatrix(UnityEngine.Matrix4x4 UnityM,Accord.Math.Matrix3x3 RotationM,Accord.Math.Vector3 Trans)
    {
              
        UnityM.m00 = RotationM.V00;
        UnityM.m10 = RotationM.V10;
        UnityM.m20 = RotationM.V20;
        
        UnityM.m01 = RotationM.V01;
        UnityM.m11 = RotationM.V11;
        UnityM.m21 = RotationM.V21;
        
        UnityM.m02 = RotationM.V02;
        UnityM.m12 = RotationM.V12;
        UnityM.m22 = RotationM.V22;


        UnityM.m03 = Trans.X;
        UnityM.m13 = Trans.Y;
        UnityM.m23 = Trans.Z;

        UnityM.m30 = 0;
        UnityM.m31 = 0;
        UnityM.m32 = 0;
        UnityM.m33 = 1;

        return UnityM;
    }

    public static UnityEngine.Matrix4x4 ApplyTransformation(UnityEngine.Vector3 p01e,UnityEngine.Vector3 p02e,UnityEngine.Vector3 p03e,UnityEngine.Vector3 p11e,UnityEngine.Vector3 p12e,UnityEngine.Vector3 p13e)
{
        Accord.Math.Vector3 p01=AcExtension.UnitytoAccord(p01e);
        Accord.Math.Vector3 p02=AcExtension.UnitytoAccord(p02e);
        Accord.Math.Vector3 p03=AcExtension.UnitytoAccord(p03e);
        Accord.Math.Vector3 p11=AcExtension.UnitytoAccord(p11e);
        Accord.Math.Vector3 p12=AcExtension.UnitytoAccord(p12e);
        Accord.Math.Vector3 p13=AcExtension.UnitytoAccord(p13e);

        //Calculating Centroids from both coordinate system
        var centroidA = (p01 + p02 + p03) / 3;
        var centroidB = (p11 + p12 + p13) / 3;
        Debug.Log("Centroid A is" + centroidA + " Centroid B is" + centroidB);

        // Calculating Covariance Matrix
        var H = AcExtension.CovarianceMatrixStep(p01 - centroidA, p11 - centroidB)
            + AcExtension.CovarianceMatrixStep(p02 - centroidA, p12 - centroidB)
            + AcExtension.CovarianceMatrixStep(p03 - centroidA, p13 - centroidB);

        Matrix3x3 U;
        Accord.Math.Vector3 E;
        Matrix3x3 V;
        Matrix3x3 R;
        H.SVD(out U, out E, out V);
        R = V * U.Transpose();        
        
        // InitPosition = TestObject.transform.position;
        // InitQT = TestObject.transform.rotation;  
        // var InitPosition1=TestObject2.transform.position;

        Debug.Log("Determinant is" + R.Determinant);
        //special reflection case
        if(R.Determinant<0)
            {
                V.V02 = (-V.V02);
                V.V12 = (-V.V12);
                V.V22 = (-V.V22);
                R = V * U.Transpose();
                Debug.LogWarning("Reflection case");
            }
        
        var Translation = AcExtension.NegativeMatrix(R) * centroidA + centroidB;
        Debug.Log("Translation is" + Translation);
        UnityEngine.Matrix4x4 TransformationMatrix=UnityEngine.Matrix4x4.identity;
        TransformationMatrix = AcExtension.AccordToUnityMatrix(TransformationMatrix, R, Translation);
        Debug.Log(TransformationMatrix);
        return TransformationMatrix;

        // InitPosition.PrintVector3("p01");
        // InitPosition1.PrintVector3("p02");

        // var p1=  TransformationMatrix.MultiplyPoint(InitPosition);
        // p1.PrintVector3("p1");//应该和p02是相同的。
        
        // // Transformaiton Matrix for Unity
        // TransformationMatrix.SetTRS(AcRTTransform.AccordtoUnity(Translation), Quaternion.LookRotation(TransformationMatrix.GetColumn(1),
        //      TransformationMatrix.GetColumn(2)), UnityEngine.Vector3.one);
        // Debug.Log(TransformationMatrix);

        // var p2=  TransformationMatrix.MultiplyPoint(InitPosition);
        // p2.PrintVector3("p2");

        // // Applying Translation and rotation to 4th point/object
        // TestObject.transform.position = TransformationMatrix.MultiplyPoint(InitPosition);
        // TestObject.transform.rotation = Quaternion.LookRotation(TransformationMatrix.GetColumn(1), TransformationMatrix.GetColumn(2))* InitQT;
    }
}
