﻿
// Rigid Transform implementation using explanation in http://nghiaho.com/?page_id=671
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Accord.Math;
using Accord;
using System;
using MeshJobs;

public class AcRigidTransform : MonoBehaviour {
    
    public static AcRigidTransform Instance;

    public void Awake()
    {
        Instance=this;
    }

    // Initial objects   
    public GameObject P01GO;
    public GameObject P02GO;
    public GameObject P03GO;

    // Transformed objects
    public GameObject P11GO;
    public GameObject P12GO;
    public GameObject P13GO;
    
    // object used as a 4th point to test Transformation Matrix
    public GameObject TestObject;

    public GameObject TestObject2;

    public AcRTPoints RTPoints;
    
    // variables used for RigidTransform
    // private Matrix3x3 H;
    // private Matrix3x3 U;
    // private Accord.Math.Vector3 E;
    // private Matrix3x3 V;
    // private Matrix3x3 R;
    // Accord.Math.Vector3 centroidA;
    // Accord.Math.Vector3 centroidB;

    UnityEngine.Matrix4x4 TransformationMatrix;
    // private Accord.Math.Vector3 Translation;

    // Saving initial position and rotation to apply transformation in Update()
    private UnityEngine.Vector3 InitPosition;
    private Quaternion InitQT;

    void Start () {
        InitPosition = TestObject.transform.position;
        InitQT = TestObject.transform.rotation;        
    }
   
    // Calculation of covariance matrix H
    static private Matrix3x3 CovarianceMatrixStep( Accord.Math.Vector3 difSetA, Accord.Math.Vector3 difSetB )
    {
        Matrix3x3 M;
        M.V00 = difSetA.X * difSetB.X;
        M.V01 = difSetA.X * difSetB.Y;
        M.V02 = difSetA.X * difSetB.Z;

        M.V10 = difSetA.Y * difSetB.X;
        M.V11 = difSetA.Y * difSetB.Y;
        M.V12 = difSetA.Y * difSetB.Z;

        M.V20 = difSetA.Z * difSetB.X;
        M.V21 = difSetA.Z * difSetB.Y;
        M.V22 = difSetA.Z * difSetB.Z;


        return M;
    }

    // Converting Unity.Vector3 to Accord.Vector3
    static private Accord.Math.Vector3 UnitytoAccord( UnityEngine.Vector3 pos )
    {
        Accord.Math.Vector3 posTransformed = new Accord.Math.Vector3();
        posTransformed.X = pos.x;
        posTransformed.Y = pos.y;
        posTransformed.Z = pos.z;

        return posTransformed;
    }
    // Converting  Accord.Vector3 to Unity.Vector3 
    static private UnityEngine.Vector3 AccordtoUnity(Accord.Math.Vector3 pos)
    {
        UnityEngine.Vector3 posTransformed = new UnityEngine.Vector3();
        posTransformed.x = pos.X;
        posTransformed.y = pos.Y;
        posTransformed.z = pos.Z;

        return posTransformed;
    }
    static  private Matrix3x3 ZeroMatrix(Matrix3x3 m)
    {
        m.V00 = 0;
        m.V01 = 0;
        m.V02 = 0;
        m.V10 = 0;
        m.V11 = 0;
        m.V12 = 0;
        m.V20 = 0;
        m.V21 = 0;
        m.V22 = 0;

        return m;
    }
    static  private Matrix3x3 NegativeMatrix(Matrix3x3 m)
    {
        m.V00 *= (-1);
        m.V01 *= (-1);
        m.V02 *= (-1);
        m.V10 *= (-1);
        m.V11 *= (-1);
        m.V12 *= (-1);
        m.V20 *= (-1);
        m.V21 *= (-1);
        m.V22 *= (-1);

        return m;
    }

    // Creating Unity Transformation matrix using 3x3 Rotation matrix and translation vector acquired from RigidTransform
    public static UnityEngine.Matrix4x4 AccordToUnityMatrix(UnityEngine.Matrix4x4 UnityM,Accord.Math.Matrix3x3 RotationM,Accord.Math.Vector3 Trans)
    {
              
        UnityM.m00 = RotationM.V00;
        UnityM.m10 = RotationM.V10;
        UnityM.m20 = RotationM.V20;
        
        UnityM.m01 = RotationM.V01;
        UnityM.m11 = RotationM.V11;
        UnityM.m21 = RotationM.V21;
        
        UnityM.m02 = RotationM.V02;
        UnityM.m12 = RotationM.V12;
        UnityM.m22 = RotationM.V22;


        UnityM.m03 = Trans.X;
        UnityM.m13 = Trans.Y;
        UnityM.m23 = Trans.Z;

        UnityM.m30 = 0;
        UnityM.m31 = 0;
        UnityM.m32 = 0;
        UnityM.m33 = 1;

        return UnityM;
    }

    [ContextMenu("InitRTPoints")]
    public void InitRTPoints()
    {
        if(P01GO==null||P02GO==null||P03GO==null||P11GO==null||P12GO==null||P13GO==null)
        {
            return;
        }
        RTPoints.p01=P01GO.transform.position;
        RTPoints.p02=P02GO.transform.position;
        RTPoints.p03=P03GO.transform.position;
        if(TestObject!=null)
        {
            RTPoints.p04=TestObject.transform.position;
            InitPosition = TestObject.transform.position;
            InitQT = TestObject.transform.rotation; 
        }
        RTPoints.p11=P11GO.transform.position;
        RTPoints.p12=P12GO.transform.position;
        RTPoints.p13=P13GO.transform.position;
        if(TestObject2!=null)
            RTPoints.p14=TestObject2.transform.position;

    }

    [ContextMenu("InitRTPoints")]
    public void CleanObjects()
    {
        P01GO=null;
        P02GO=null;
        P03GO=null;
        P11GO=null;
        P12GO=null;
        P13GO=null;
    }

    public bool IsReflection=false;

    // [ContextMenu("ApplyTransformation4")]
    // public void ApplyTransformation4()
    // {   
    //     InitRTPoints();

    //     //改成基于4个点进行的变换。4个点一个是中心，一个是法线，2个是法平面上的两点

    //     //centroid:质心
    //     //Calculating Centroids from both coordinate system
    //     centroidA = (UnitytoAccord(p01) + UnitytoAccord(p02) + UnitytoAccord(p03) + UnitytoAccord(p04)) / 4;
    //     centroidB = (UnitytoAccord(p11) + UnitytoAccord(p12) + UnitytoAccord(p13) + UnitytoAccord(p14)) / 4;
    //     //Debug.Log("Centroid A is" + centroidA + " Centroid B is" + centroidB);

    //     // Calculating Covariance Matrix
    //     H = CovarianceMatrixStep(UnitytoAccord(p01) - centroidA, UnitytoAccord(p11) - centroidB)
    //         + CovarianceMatrixStep(UnitytoAccord(p02) - centroidA, UnitytoAccord(p12) - centroidB)
    //         + CovarianceMatrixStep(UnitytoAccord(p03) - centroidA, UnitytoAccord(p13) - centroidB)
    //         + CovarianceMatrixStep(UnitytoAccord(p04) - centroidA, UnitytoAccord(p14) - centroidB);

    //     H.SVD(out U, out E, out V);
    //     R = V * U.Transpose();      

    //     Debug.Log("R.Determinant is" + R.Determinant);
    //     //special reflection case
    //     if(R.Determinant<0)
    //         {
    //             IsReflection=true;
    //             V.V02 = (-V.V02);
    //             V.V12 = (-V.V12);
    //             V.V22 = (-V.V22);
    //             R = V * U.Transpose();
    //             Debug.LogWarning("Reflection case");
    //             Debug.Log("R.Determinant is" + R.Determinant);
    //         }
    //         else{
    //             IsReflection=false;
    //         }
        
    //     // InitPosition.PrintVector3("P01");
    //     // TestObject2.transform.position.PrintVector3("P02");

    //     Translation = NegativeMatrix(R) * centroidA + centroidB;
    //     TransformationMatrix = AccordToUnityMatrix(TransformationMatrix, R, Translation);
    //     Debug.Log(TransformationMatrix);
        
    //     // // Transformaiton Matrix for Unity
    //     // TransformationMatrix.SetTRS(AccordtoUnity(Translation), Quaternion.LookRotation(TransformationMatrix.GetColumn(1),
    //     //      TransformationMatrix.GetColumn(2)), UnityEngine.Vector3.one);
    //     // Debug.Log(TransformationMatrix);

    //     // // Applying Translation and rotation to 4th point/object
    //     // TestObject.transform.position = TransformationMatrix.MultiplyPoint(InitPosition);
    //     // TestObject.transform.rotation = Quaternion.LookRotation(TransformationMatrix.GetColumn(1), TransformationMatrix.GetColumn(2))* InitQT;
    // }

    [ContextMenu("ApplyTransformation4")]
    public RTResult ApplyTransformation4()
    {   
        var result=ApplyTransformation4(RTPoints);
        this.IsReflection=result.IsReflection;
        this.TransformationMatrix=result.TransformationMatrix;
        return result;
    }

    [ContextMenu("ApplyTransformation4")]
    public static RTResult ApplyTransformation4(AcRTPoints points)
    {   
        RTResult result=new RTResult();

        //改成基于4个点进行的变换。4个点一个是中心，一个是法线，2个是法平面上的两点

        //centroid:质心
        //Calculating Centroids from both coordinate system
        var centroidA = (UnitytoAccord(points.p01) + UnitytoAccord(points.p02) + UnitytoAccord(points.p03) + UnitytoAccord(points.p04)) / 4;
        var centroidB = (UnitytoAccord(points.p11) + UnitytoAccord(points.p12) + UnitytoAccord(points.p13) + UnitytoAccord(points.p14)) / 4;
        //Debug.Log("Centroid A is" + centroidA + " Centroid B is" + centroidB);

        // Calculating Covariance Matrix
        var H = CovarianceMatrixStep(UnitytoAccord(points.p01) - centroidA, UnitytoAccord(points.p11) - centroidB)
            + CovarianceMatrixStep(UnitytoAccord(points.p02) - centroidA, UnitytoAccord(points.p12) - centroidB)
            + CovarianceMatrixStep(UnitytoAccord(points.p03) - centroidA, UnitytoAccord(points.p13) - centroidB)
            + CovarianceMatrixStep(UnitytoAccord(points.p04) - centroidA, UnitytoAccord(points.p14) - centroidB);

        Matrix3x3 U;
        Accord.Math.Vector3 E;
        Matrix3x3 V;

        H.SVD(out U, out E, out V);
        var R = V * U.Transpose();      

        Debug.Log("R.Determinant is" + R.Determinant);
        //special reflection case
        if(R.Determinant<0)
            {
                result.IsReflection=true;
                V.V02 = (-V.V02);
                V.V12 = (-V.V12);
                V.V22 = (-V.V22);
                R = V * U.Transpose();
                Debug.LogWarning("Reflection case");
                Debug.Log("R.Determinant is" + R.Determinant);
            }
            else{
                result.IsReflection=false;
            }
        
        // InitPosition.PrintVector3("P01");
        // TestObject2.transform.position.PrintVector3("P02");
        
        

        var T = NegativeMatrix(R) * centroidA + centroidB;
        // UnityEngine.Matrix4x4 matrix=UnityEngine.Matrix4x4.identity;
        // TransformationMatrix = AccordToUnityMatrix(matrix, R, Translation);
        // Debug.Log(TransformationMatrix);
        
        
        result.SetRT(R,T);
        Debug.Log(result.TransformationMatrix);

        result.TestApplyPoint(points.p04,points.p14);//确认转换后的坐标是否正确

        return result;

        // // Transformaiton Matrix for Unity
        // TransformationMatrix.SetTRS(AccordtoUnity(Translation), Quaternion.LookRotation(TransformationMatrix.GetColumn(1),
        //      TransformationMatrix.GetColumn(2)), UnityEngine.Vector3.one);
        // Debug.Log(TransformationMatrix);

        // // Applying Translation and rotation to 4th point/object
        // TestObject.transform.position = TransformationMatrix.MultiplyPoint(InitPosition);
        // TestObject.transform.rotation = Quaternion.LookRotation(TransformationMatrix.GetColumn(1), TransformationMatrix.GetColumn(2))* InitQT;
    }

    // Function to apply transformation to 4th point/object
    // [ContextMenu("ApplyTransformation")]
    // public void ApplyTransformation()
    // {   
    //     InitRTPoints();
    //     //centroid:质心
    //     //Calculating Centroids from both coordinate system
    //     centroidA = (UnitytoAccord(p01) + UnitytoAccord(p02)
    //               + UnitytoAccord(p03)) / 3;
    //     centroidB = (UnitytoAccord(p11) + UnitytoAccord(p12)
    //               + UnitytoAccord(p13)) / 3;
    //     //Debug.Log("Centroid A is" + centroidA + " Centroid B is" + centroidB);

    //     // Calculating Covariance Matrix
    //     H = CovarianceMatrixStep(UnitytoAccord(p01) - centroidA, UnitytoAccord(p11) - centroidB)
    //         + CovarianceMatrixStep(UnitytoAccord(p02) - centroidA, UnitytoAccord(p12) - centroidB)
    //         + CovarianceMatrixStep(UnitytoAccord(p03) - centroidA, UnitytoAccord(p13) - centroidB);

    //     H.SVD(out U, out E, out V);
    //     R = V * U.Transpose();      

    //     Debug.Log("R.Determinant is" + R.Determinant);
    //     //special reflection case
    //     if(R.Determinant<0)
    //         {
    //             IsReflection=true;
    //             V.V02 = (-V.V02);
    //             V.V12 = (-V.V12);
    //             V.V22 = (-V.V22);
    //             R = V * U.Transpose();
    //             Debug.LogWarning("Reflection case");
    //             Debug.Log("R.Determinant is" + R.Determinant);
    //         }
        
    //     // InitPosition.PrintVector3("P01");
    //     // TestObject2.transform.position.PrintVector3("P02");

    //     Translation = NegativeMatrix(R) * centroidA + centroidB;
    //     TransformationMatrix = AccordToUnityMatrix(TransformationMatrix, R, Translation);
    //     Debug.Log(TransformationMatrix);
        
    //     // // Transformaiton Matrix for Unity
    //     // TransformationMatrix.SetTRS(AccordtoUnity(Translation), Quaternion.LookRotation(TransformationMatrix.GetColumn(1),
    //     //      TransformationMatrix.GetColumn(2)), UnityEngine.Vector3.one);
    //     // Debug.Log(TransformationMatrix);

    //     // // Applying Translation and rotation to 4th point/object
    //     // TestObject.transform.position = TransformationMatrix.MultiplyPoint(InitPosition);
    //     // TestObject.transform.rotation = Quaternion.LookRotation(TransformationMatrix.GetColumn(1), TransformationMatrix.GetColumn(2))* InitQT;
    // }

    public void ApplyTransform(Transform t)
    {
        Debug.LogError("ApplyTransform:"+t);
        Debug.LogError(TransformationMatrix);
        Debug.LogError(t.position);
        Debug.LogError(t.rotation);
        var pos=t.position;
        var qt=t.rotation;

        //TransformationMatrix.SetTRS(AccordtoUnity(Translation), Quaternion.LookRotation(TransformationMatrix.GetColumn(1),TransformationMatrix.GetColumn(2)), UnityEngine.Vector3.one);
        t.position = TransformationMatrix.MultiplyPoint(pos);
        //t.rotation = Quaternion.LookRotation(TransformationMatrix.GetColumn(1), TransformationMatrix.GetColumn(2))* qt;
        t.rotation = Quaternion.LookRotation(TransformationMatrix.GetColumn(2), TransformationMatrix.GetColumn(1))* qt;

        // t.rotation = Quaternion.LookRotation(TransformationMatrix.GetColumn(0), TransformationMatrix.GetColumn(1))* qt;
        // t.rotation = Quaternion.LookRotation(TransformationMatrix.GetColumn(1), TransformationMatrix.GetColumn(0))* qt;

        //t.rotation = Quaternion.LookRotation(TransformationMatrix.GetColumn(0), TransformationMatrix.GetColumn(2))* qt;
        //t.rotation = Quaternion.LookRotation(TransformationMatrix.GetColumn(2), TransformationMatrix.GetColumn(0))* qt;

        // UnityEngine.Matrix4x4 matrix=UnityEngine.Matrix4x4.identity;
        // matrix.SetTRS(AccordtoUnity(Translation), Quaternion.LookRotation(TransformationMatrix.GetColumn(1),TransformationMatrix.GetColumn(2)), UnityEngine.Vector3.one);
        // t.position = matrix.MultiplyPoint(t.position);
        // //t.rotation = Quaternion.LookRotation(matrix.GetColumn(1), matrix.GetColumn(2))* qt;

        Debug.LogError(t.position);
        Debug.LogError(t.rotation);
    }

    public static AcRTPoints GetRTPoints(ThreePoint tpFrom,ThreePoint tpTo)
    {
        AcRTPoints points=new AcRTPoints();
        points.p01=tpFrom.GetMaxP();
        points.p02=tpFrom.GetMinP();
        points.p03=tpFrom.GetCenterP();
        points.p04=tpFrom.GetNormalP();//法线
        points.p05=tpFrom.GetMaxP();

        points.p11=tpTo.GetMaxP();
        points.p12=tpTo.GetMinP();
        points.p13=tpTo.GetCenterP();
        points.p14=tpTo.GetNormalP();//法线
        points.p15=tpTo.GetMaxP();
        return points;
    }

    public RTResult GetRTMatrix(ThreePoint tpFrom,ThreePoint tpTo)
    {
        RTPoints=GetRTPoints(tpFrom,tpTo);
        return this.GetRTMatrix();//脚本内的
    }

    public static RTResult GetRTMatrixS(ThreePoint tpFrom,ThreePoint tpTo)
    {
        var RTPoints=GetRTPoints(tpFrom,tpTo);
        var result=ApplyTransformation4(RTPoints);
        //return result.TransformationMatrix;
        return result;
    }

    public static void ApplyMatrix(UnityEngine.Matrix4x4 matrix,Transform t)
    {
        var pos=t.position;
        var qt=t.rotation;
        t.position = matrix.MultiplyPoint(pos);
        t.rotation = Quaternion.LookRotation(matrix.GetColumn(2), matrix.GetColumn(1))* qt;
    }


    [ContextMenu("ResetTransformationMatrix")]
    public void ResetTransformationMatrix()
    {
        TransformationMatrix=UnityEngine.Matrix4x4.zero;
    }

    // [ContextMenu("TestApplyTransformation")]
    // public void TestApplyTransformation()
    // {
    //     ResetTransformationMatrix();
    //     ApplyTransformation();
    //     TestApplyPoint();
    // }

    [ContextMenu("TestApplyTransformation4")]
    public RTResult GetRTMatrix()
    {
        ResetTransformationMatrix();
        RTResult result=ApplyTransformation4();
        TestApplyPoint();
        return result;
    }

    private float lastDistance1;

    private float lastDistance2;

    public bool IsZero=true;

    [ContextMenu("TestApplyPoint")]
    public void TestApplyPoint()
    {
        IsZero=true;
        RTPoints.p04.PrintVector3("p04");
        RTPoints.p14.PrintVector3("p14");
        var p142=TransformationMatrix.MultiplyPoint(RTPoints.p04);
        p142.PrintVector3("p142");
        float dis1=UnityEngine.Vector3.Distance(RTPoints.p14,p142);
        float dd1=Mathf.Abs(lastDistance1-dis1);
        lastDistance1=dis1;
        Debug.Log("dis1:"+dis1+"|dd:"+dd1);
        if(dis1>0.000001)
        {
            Debug.LogWarning("TestApplyPoint dis>0.000001");
            IsZero=false;
        }

        RTPoints.p05.PrintVector3("p05");
        RTPoints.p15.PrintVector3("p15");
        var p152=TransformationMatrix.MultiplyPoint(RTPoints.p05);
        p152.PrintVector3("p152");
        float dis2=UnityEngine.Vector3.Distance(RTPoints.p15,p152);
        float dd2=Mathf.Abs(lastDistance2-dis2);
        lastDistance2=dis2;
        Debug.Log("dis2:"+dis2+"|dd:"+dd2);
        if(dis2>0.000001)
        {
            Debug.LogWarning("TestApplyPoint dis>0.000001");
            IsZero=false;
        }

        //Debug.LogWarning("IsZero:"+IsZero);
    }

    public UnityEngine.Vector3 ApplyPoint(UnityEngine.Vector3 p1)
    {
        p1.PrintVector3("P1");
        var p2=TransformationMatrix.MultiplyPoint(p1);
        p2.PrintVector3("P2");
        return p2;
    }

    // // Update is called once per frame
    // void Update () {           
    //        ApplyTransformation();        
    // }

    // public static void RTAlign(MeshFilter mfFrom,MeshFilter mfTo)
    // {
    //     DateTime start=DateTime.Now;

    //     MeshJobHelper.NewThreePointJobs(new MeshFilter[]{mfFrom,mfTo},10000);
    //     // MeshJobs.NewMeshAlignJob(go1, go2Copy,true);
    //     RTAlignOneCore(mfFrom,mfTo);
    // }

    public static void RTAlign(MeshFilter mfFrom,MeshFilter mfTo)
    {
        DateTime start=DateTime.Now;

        Transform tFrom=mfFrom.transform;
        Transform tTo=mfTo.transform;
        // ThreePointJobResult resultFrom=ThreePointJobResultList.Instance.GetThreePoint(mfFrom);
        // resultFrom.localToWorldMatrix=tFrom.localToWorldMatrix;

        // ThreePointJobResult resultTo=ThreePointJobResultList.Instance.GetThreePoint(mfTo);
        // resultTo.localToWorldMatrix=tTo.localToWorldMatrix;

        var tpsFrom = ThreePointJobResultList.Instance.GetThreePoints(mfFrom);
        var tpsTo = ThreePointJobResultList.Instance.GetThreePoints(mfTo); 

        MeshHelper.ClearChildren(tFrom);
        MeshHelper.ClearChildren(tTo);

        AcRigidTransform acRigidTransform=GetAcRigidTransform();
        int count=0;

        float minDis=float.MaxValue;
        RTResult minRT=new RTResult();

        var vsFrom=MeshHelper.GetWorldVertexes(mfFrom);
        var vsTo=MeshHelper.GetWorldVertexes(mfTo);
        bool isFound=false;
        for(int l=0;l<tpsFrom.Length;l++)
        {
            var tpFrom=tpsFrom[l];
            for(int k=0;k<tpsTo.Length;k++)
            {
                var tpTo=tpsTo[k];
                count++;
                var rt=acRigidTransform.GetRTMatrix(tpFrom,tpTo);//核心,基于脚本的
                //var rt=GetRTMatrixS(tpFrom,tpTo);//核心，静态函数的
                MeshHelper.ClearChildren(tFrom);
                var vsNew=rt.ApplyPoints(vsFrom);
                var dis=DistanceUtil.GetDistance(vsTo,vsNew);
                if(dis<minDis){
                    minDis=dis;
                    minRT=rt;
                }
                Debug.LogError($">>>RTAlignOneCore [{l},{k}]\tIsZero:{rt.IsZero},\tIsReflection:{rt.IsReflection},\tdis:{dis}");
                if(dis==0)
                {
                    Debug.LogError($"RTAlignOneCore2 Count:{count},Time:{(DateTime.Now-start).TotalMilliseconds}ms");
                    //acRigidTransform.ApplyTransform(t1);
                    
                    //AcRigidTransform.ApplyMatrix(matrix,tFrom);
                    rt.ApplyMatrix(tFrom);
                    var gos=MeshHelper.ShowVertexes(vsNew,0.005f,tFrom);//0.1,0.005
                    isFound=true;
                    return;
                }
            }
            //break;
        }

        if(isFound==false){
            var vsNew=minRT.ApplyPoints(vsFrom);
            minRT.ApplyMatrix(tFrom);
            var gos=MeshHelper.ShowVertexes(vsNew,0.005f,tFrom);//0.1,0.005
        }

        //if(minDis<AcRTAlignJobResult.MinDis)
        // {
        //     minRT.ApplyMatrix(tFrom);
        // }

         Debug.LogError($"RTAlignOneCore Count:{count},Time:{(DateTime.Now-start).TotalMilliseconds}ms");
    }

    public static AcRigidTransform acRigidTransform;

    private static AcRigidTransform GetAcRigidTransform()
    {
        if(acRigidTransform==null){
            acRigidTransform=AcRigidTransform.Instance;
        }
        if(acRigidTransform==null){
            acRigidTransform=GameObject.FindObjectOfType<AcRigidTransform>();
        }
        if(acRigidTransform==null){
            GameObject tmp=new GameObject("AcRigidTransform");
            acRigidTransform=tmp.AddComponent<AcRigidTransform>();
        }
        acRigidTransform.CleanObjects();
        return acRigidTransform;
    }
}

public struct AcRTPoints
{
    public UnityEngine.Vector3 p01; 
    public UnityEngine.Vector3 p02;
    public UnityEngine.Vector3 p03;

    public UnityEngine.Vector3 p11; 
    public UnityEngine.Vector3 p12;
    public UnityEngine.Vector3 p13;

    public UnityEngine.Vector3 p04;

    public UnityEngine.Vector3 p14;

    public UnityEngine.Vector3 p05;

    public UnityEngine.Vector3 p15;
}

public struct RTResult
{
    public UnityEngine.Matrix4x4 TransformationMatrix;
    public Accord.Math.Vector3 Translation;

    public Matrix3x3 R;

    public bool IsZero;

    public bool IsReflection;

    public float Distance;

    public void SetRT(Matrix3x3 r,Accord.Math.Vector3 t)
    {
        this.R=r;
        this.Translation=t;
        UnityEngine.Matrix4x4 matrix=UnityEngine.Matrix4x4.identity;
        TransformationMatrix = AcRigidTransform.AccordToUnityMatrix(matrix, R, Translation);
        
    }

    internal UnityEngine.Vector3[] ApplyPoints(UnityEngine.Vector3[] vs2)
    {
        UnityEngine.Vector3[] vs3=new UnityEngine.Vector3[vs2.Length];
        for(int i=0;i<vs2.Length;i++)
        {
            vs3[i]=TransformationMatrix.MultiplyPoint(vs2[i]);
        }
            return vs3;
    }

    public void ApplyMatrix(Transform t)
    {
        var pos=t.position;
        var qt=t.rotation;
        t.position = TransformationMatrix.MultiplyPoint(pos);
        t.rotation = Quaternion.LookRotation(TransformationMatrix.GetColumn(2), TransformationMatrix.GetColumn(1))* qt;
    }

    private float lastDistance1;

    public void TestApplyPoint(UnityEngine.Vector3 pFrom,UnityEngine.Vector3 pTo)
    {
        IsZero=true;
        pFrom.PrintVector3("pFrom");
        pTo.PrintVector3("pTo");
        var pTo2=TransformationMatrix.MultiplyPoint(pFrom);
        pTo2.PrintVector3("pTo2");
        float dis1=UnityEngine.Vector3.Distance(pTo,pTo2);
        float dd1=Mathf.Abs(lastDistance1-dis1);
        lastDistance1=dis1;
        Debug.Log("dis1:"+dis1+"|dd:"+dd1);
        if(dis1>0.00001)
        {
            Debug.LogWarning("TestApplyPoint dis>0.000001");
            IsZero=false;
        }

        // RTPoints.p05.PrintVector3("p05");
        // RTPoints.p15.PrintVector3("p15");
        // var p152=TransformationMatrix.MultiplyPoint(RTPoints.p05);
        // p152.PrintVector3("p152");
        // float dis2=UnityEngine.Vector3.Distance(RTPoints.p15,p152);
        // float dd2=Mathf.Abs(lastDistance2-dis2);
        // lastDistance2=dis2;
        // Debug.Log("dis2:"+dis2+"|dd:"+dd2);
        // if(dis2>0.000001)
        // {
        //     Debug.LogWarning("TestApplyPoint dis>0.000001");
        //     IsZero=false;
        // }

        //Debug.LogWarning("IsZero:"+IsZero);
    }

}