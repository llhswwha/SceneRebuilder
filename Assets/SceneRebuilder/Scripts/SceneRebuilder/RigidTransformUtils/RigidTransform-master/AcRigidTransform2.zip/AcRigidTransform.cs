﻿
// Rigid Transform implementation using explanation in http://nghiaho.com/?page_id=671
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Accord.Math;
using Accord;

public class AcRigidTransform : MonoBehaviour {
    
    public static AcRigidTransform Instance;

    public void Awake()
    {
        Instance=this;
    }

    // Initial objects   
    public GameObject CubeReg;
    public GameObject SphereReg;
    public GameObject CylinderReg;

    // Transformed objects
    public GameObject CubeTransformed;
    public GameObject SphereTransformed;
    public GameObject CylinderTransformed;
    
    // object used as a 4th point to test Transformation Matrix
    public GameObject TestObject;

    public GameObject TestObject2;

    public UnityEngine.Vector3 p01; 
    public UnityEngine.Vector3 p02;
    public UnityEngine.Vector3 p03;
    public UnityEngine.Vector3 p04;

    public UnityEngine.Vector3 p05;
    public UnityEngine.Vector3 p11; 
    public UnityEngine.Vector3 p12;
    public UnityEngine.Vector3 p13;
    public UnityEngine.Vector3 p14;

    public UnityEngine.Vector3 p15;
    
    // variables used for RigidTransform
    private Matrix3x3 H;
    private Matrix3x3 U;
    private Accord.Math.Vector3 E;
    private Matrix3x3 V;
    private Matrix3x3 R;
    Accord.Math.Vector3 centroidA;
    Accord.Math.Vector3 centroidB;
    Accord.Math.Vector4 x;
    UnityEngine.Matrix4x4 TransformationMatrix;
    private Accord.Math.Vector3 Translation;

    // Saving initial position and rotation to apply transformation in Update()
    private UnityEngine.Vector3 InitPosition;
    private Quaternion InitQT;

    void Start () {
        InitPosition = TestObject.transform.position;
        InitQT = TestObject.transform.rotation;        
    }
   
    // Calculation of covariance matrix H
    private Matrix3x3 CovarianceMatrixStep( Accord.Math.Vector3 difSetA, Accord.Math.Vector3 difSetB )
    {
        Matrix3x3 M;
        M.V00 = difSetA.X * difSetB.X;
        M.V01 = difSetA.X * difSetB.Y;
        M.V02 = difSetA.X * difSetB.Z;

        M.V10 = difSetA.Y * difSetB.X;
        M.V11 = difSetA.Y * difSetB.Y;
        M.V12 = difSetA.Y * difSetB.Z;

        M.V20 = difSetA.Z * difSetB.X;
        M.V21 = difSetA.Z * difSetB.Y;
        M.V22 = difSetA.Z * difSetB.Z;


        return M;
    }

    // Converting Unity.Vector3 to Accord.Vector3
    private Accord.Math.Vector3 UnitytoAccord( UnityEngine.Vector3 pos )
    {
        Accord.Math.Vector3 posTransformed = new Accord.Math.Vector3();
        posTransformed.X = pos.x;
        posTransformed.Y = pos.y;
        posTransformed.Z = pos.z;

        return posTransformed;
    }
    // Converting  Accord.Vector3 to Unity.Vector3 
    private UnityEngine.Vector3 AccordtoUnity(Accord.Math.Vector3 pos)
    {
        UnityEngine.Vector3 posTransformed = new UnityEngine.Vector3();
        posTransformed.x = pos.X;
        posTransformed.y = pos.Y;
        posTransformed.z = pos.Z;

        return posTransformed;
    }
    private Matrix3x3 ZeroMatrix(Matrix3x3 m)
    {
        m.V00 = 0;
        m.V01 = 0;
        m.V02 = 0;
        m.V10 = 0;
        m.V11 = 0;
        m.V12 = 0;
        m.V20 = 0;
        m.V21 = 0;
        m.V22 = 0;

        return m;
    }
    private Matrix3x3 NegativeMatrix(Matrix3x3 m)
    {
        m.V00 *= (-1);
        m.V01 *= (-1);
        m.V02 *= (-1);
        m.V10 *= (-1);
        m.V11 *= (-1);
        m.V12 *= (-1);
        m.V20 *= (-1);
        m.V21 *= (-1);
        m.V22 *= (-1);

        return m;
    }

    // Creating Unity Transformation matrix using 3x3 Rotation matrix and translation vector acquired from RigidTransform
    UnityEngine.Matrix4x4 AccordToUnityMatrix(UnityEngine.Matrix4x4 UnityM,Accord.Math.Matrix3x3 RotationM,Accord.Math.Vector3 Trans)
    {
              
        UnityM.m00 = RotationM.V00;
        UnityM.m10 = RotationM.V10;
        UnityM.m20 = RotationM.V20;
        
        UnityM.m01 = RotationM.V01;
        UnityM.m11 = RotationM.V11;
        UnityM.m21 = RotationM.V21;
        
        UnityM.m02 = RotationM.V02;
        UnityM.m12 = RotationM.V12;
        UnityM.m22 = RotationM.V22;


        UnityM.m03 = Trans.X;
        UnityM.m13 = Trans.Y;
        UnityM.m23 = Trans.Z;

        UnityM.m30 = 0;
        UnityM.m31 = 0;
        UnityM.m32 = 0;
        UnityM.m33 = 1;

        return UnityM;
    }

    [ContextMenu("InitRTPoints")]
    public void InitRTPoints()
    {
        if(CubeReg==null||SphereReg==null||CylinderReg==null||CubeTransformed==null||SphereTransformed==null||CylinderTransformed==null)
        {
            return;
        }
        p01=CubeReg.transform.position;
        p02=SphereReg.transform.position;
        p03=CylinderReg.transform.position;
        if(TestObject!=null)
        {
            p04=TestObject.transform.position;
            InitPosition = TestObject.transform.position;
            InitQT = TestObject.transform.rotation; 
        }
        p11=CubeTransformed.transform.position;
        p12=SphereTransformed.transform.position;
        p13=CylinderTransformed.transform.position;
        if(TestObject2!=null)
            p14=TestObject2.transform.position;

    }

    [ContextMenu("InitRTPoints")]
    public void CleanObjects()
    {
        CubeReg=null;
        SphereReg=null;
        CylinderReg=null;
        CubeTransformed=null;
        SphereTransformed=null;
        CylinderTransformed=null;
    }

    // Function to apply transformation to 4th point/object
    [ContextMenu("ApplyTransformation")]
    public void ApplyTransformation()
    {   
        InitRTPoints();

        //Calculating Centroids from both coordinate system
        centroidA = (UnitytoAccord(p01) + UnitytoAccord(p02)
                  + UnitytoAccord(p03)) / 3;
        centroidB = (UnitytoAccord(p11) + UnitytoAccord(p12)
                  + UnitytoAccord(p13)) / 3;
        //Debug.Log("Centroid A is" + centroidA + " Centroid B is" + centroidB);

        // Calculating Covariance Matrix
        H = CovarianceMatrixStep(UnitytoAccord(p01) - centroidA, UnitytoAccord(p11) - centroidB)
            + CovarianceMatrixStep(UnitytoAccord(p02) - centroidA, UnitytoAccord(p12) - centroidB)
            + CovarianceMatrixStep(UnitytoAccord(p03) - centroidA, UnitytoAccord(p13) - centroidB);

        H.SVD(out U, out E, out V);
        R = V * U.Transpose();      

        Debug.Log("R.Determinant is" + R.Determinant);
        //special reflection case
        if(R.Determinant<0)
            {
                V.V02 = (-V.V02);
                V.V12 = (-V.V12);
                V.V22 = (-V.V22);
                R = V * U.Transpose();
                Debug.LogWarning("Reflection case");
            }
        
        // InitPosition.PrintVector3("P01");
        // TestObject2.transform.position.PrintVector3("P02");

        Translation = NegativeMatrix(R) * centroidA + centroidB;
        TransformationMatrix = AccordToUnityMatrix(TransformationMatrix, R, Translation);
        //Debug.Log(TransformationMatrix);
        
        // Transformaiton Matrix for Unity
        TransformationMatrix.SetTRS(AccordtoUnity(Translation), Quaternion.LookRotation(TransformationMatrix.GetColumn(1),
             TransformationMatrix.GetColumn(2)), UnityEngine.Vector3.one);
        
        // // Applying Translation and rotation to 4th point/object
        // TestObject.transform.position = TransformationMatrix.MultiplyPoint(InitPosition);
        // TestObject.transform.rotation = Quaternion.LookRotation(TransformationMatrix.GetColumn(1), TransformationMatrix.GetColumn(2))* InitQT;
    }

    [ContextMenu("ResetTransformationMatrix")]
    public void ResetTransformationMatrix()
    {
        TransformationMatrix=UnityEngine.Matrix4x4.zero;
    }

    [ContextMenu("TestApplyTransformation")]
    public void TestApplyTransformation()
    {
        ResetTransformationMatrix();
        ApplyTransformation();
        TestApplyPoint();
    }

    private float lastDistance1;

    private float lastDistance2;

    [ContextMenu("TestApplyPoint")]
    public void TestApplyPoint()
    {
        p04.PrintVector3("p04");
        p14.PrintVector3("p14");
        var p142=TransformationMatrix.MultiplyPoint(p04);
        p142.PrintVector3("p142");
        float dis1=UnityEngine.Vector3.Distance(p14,p142);
        float dd1=Mathf.Abs(lastDistance1-dis1);
        lastDistance1=dis1;
        Debug.Log("dis1:"+dis1+"|dd:"+dd1);
        if(dis1>0.000001)
        {
            Debug.LogError("TestApplyPoint dis>0.000001");
        }

        p05.PrintVector3("p05");
        p15.PrintVector3("p15");
        var p152=TransformationMatrix.MultiplyPoint(p05);
        p152.PrintVector3("p152");
        float dis2=UnityEngine.Vector3.Distance(p15,p152);
        float dd2=Mathf.Abs(lastDistance2-dis2);
        lastDistance2=dis2;
        Debug.Log("dis2:"+dis2+"|dd:"+dd2);
        if(dis2>0.000001)
        {
            Debug.LogError("TestApplyPoint dis>0.000001");
        }
    }

    public UnityEngine.Vector3 ApplyPoint(UnityEngine.Vector3 p1)
    {
        p1.PrintVector3("P1");
        var p2=TransformationMatrix.MultiplyPoint(p1);
        p2.PrintVector3("P2");
        return p2;
    }

    // Update is called once per frame
    void Update () {           
           ApplyTransformation();        
    }
}
