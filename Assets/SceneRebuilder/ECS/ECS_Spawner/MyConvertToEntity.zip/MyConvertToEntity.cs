﻿using System;
using System.Collections;
using System.Collections.Generic;
using Unity.Entities;
using UnityEngine;
using Unity.Entities.Conversion;
using UnityObject = UnityEngine.Object;
//using static Unity.Debug;

namespace Unity.MyEntities
{
    [DisallowMultipleComponent]
    public class MyConvertToEntity : MonoBehaviour
    {
        public enum Mode
        {
            ConvertAndDestroy,
            ConvertAndInjectGameObject
        }

        public Mode ConversionMode;

        void Awake()
        {
            if (World.DefaultGameObjectInjectionWorld != null)
            {
                var system = World.DefaultGameObjectInjectionWorld.GetOrCreateSystem<MyConvertToEntitySystem>();
                system.AddToBeConverted(World.DefaultGameObjectInjectionWorld, this);
            }
            else
            {
                UnityEngine.Debug.LogWarning($"{nameof(MyConvertToEntity)} failed because there is no {nameof(World.DefaultGameObjectInjectionWorld)}", this);
            }
        }
    }

    public class MyConvertToEntitySystem : GameObjectConversionSystem
    {
        Dictionary<World, List<MyConvertToEntity>> m_ToBeConverted = new Dictionary<World, List<MyConvertToEntity>>();

        //public BlobAssetStore BlobAssetStore { get; private set; }

        protected override void OnCreate()
        {
            base.OnCreate();
            //BlobAssetStore = new BlobAssetStore();
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();
            //if (BlobAssetStore != null)
            //{
            //    BlobAssetStore.Dispose();
            //    BlobAssetStore = null;
            //}
        }

        new World World => throw new InvalidOperationException($"Do not use 'this.World' directory (use {nameof(m_ToBeConverted)})");
        protected override void OnUpdate()
        {
            if (m_ToBeConverted.Count != 0)
            {
                Convert();
            }
        }

        public void AddToBeConverted(World world, MyConvertToEntity convertToEntity)
        {
            if (!m_ToBeConverted.TryGetValue(world, out var list))
            {
                list = new List<MyConvertToEntity>();
                m_ToBeConverted.Add(world, list);
            }
            list.Add(convertToEntity);
        }

        static bool IsConvertAndInject(GameObject go)
        {
            var mode = go.GetComponent<MyConvertToEntity>()?.ConversionMode;
            return mode == MyConvertToEntity.Mode.ConvertAndInjectGameObject;
        }

        static void AddRecurse(EntityManager manager, Transform transform, HashSet<Transform> toBeDetached, List<Transform> toBeInjected)
        {
            if (transform.GetComponent<MyStopConvertToEntity>() != null)
            {
                toBeDetached.Add(transform);
                return;
            }

            GameObjectEntity.AddToEntityManager(manager, transform.gameObject);
            if (IsConvertAndInject(transform.gameObject))
            {
                toBeDetached.Add(transform);
                toBeInjected.Add(transform);
            }
            else
            {
                foreach (Transform child in transform)
                {
                    AddRecurse(manager, child, toBeDetached, toBeInjected);
                }
            }
        }

//        static void InjectOriginalComponents(GameObjectConversionMappingSystem mappingSystem, Transform transform)
//        {
//            var entity = mappingSystem.GetPrimaryEnity(transform.gameObject);
//            foreach(var com in transform.GetComponents<Component>())
//            {
//#pragma warning disable 618 //remove once 
//                if (com is GameObjectEntity || com is MyConvertToEntity || com is ComponentDataProxyBase || com is MyStopConvertToEntity)
//                    continue;
//#pragma warning restore 618
//                mappingSystem.DstEntityManager.AddComponentObject(entity, com);
//            }
//        }

        void InjectOriginalComponents(Transform transform)
        {
            var entity = this.GetPrimaryEntity(transform.gameObject);
            foreach (var com in transform.GetComponents<Component>())
            {
#pragma warning disable 618 //remove once 
                if (com is GameObjectEntity || com is MyConvertToEntity || com is ComponentDataProxyBase || com is MyStopConvertToEntity)
                    continue;
#pragma warning restore 618
                this.DstEntityManager.AddComponentObject(entity, com);
            }
        }

        public void Convert()
        {
            var toBeDetached = new HashSet<Transform>();
            var conversionRoots = new HashSet<GameObject>();

            try
            {
                var toBeInjectd = new List<Transform>();
                foreach (var convertToWorld in m_ToBeConverted)
                {
                    var toBeConverted = convertToWorld.Value;
                    var settings = new GameObjectConversionSettings(
                        convertToWorld.Key,
                        GameObjectConversionUtility.ConversionFlags.AssignName
                        , BlobAssetStore);
                    settings.FilterFlags = WorldSystemFilterFlags.HybridGameObjectConversion;
                    //settings.BlobAssetStore = BlobAssetStore;

                    using (var gameOjectWorld = settings.CreateConversionWorld())
                    {
                        toBeConverted.RemoveAll(convert =>
                        {
                            if(convert.GetComponent<MyStopConvertToEntity>()!=null)
                            {
                                Debug.LogWarning($"{nameof(MyConvertToEntity)} will be ignored because of a {nameof(MyStopConvertToEntity)} on the same GameObject", convert.gameObject);
                                return true;
                            }

                            var parent = convert.transform.parent;
                            var remove = parent != null && parent.GetComponentInParent<MyConvertToEntity>() != null;
                            if (remove && parent.GetComponentInParent<MyStopConvertToEntity>() != null)
                            {
                                Debug.LogWarning($"{nameof(MyConvertToEntity)} will be ignored because of a {nameof(MyStopConvertToEntity)} higher in the hierarchy", convert.gameObject);
                            }
                            return remove;
                        });

                        foreach (var convert in toBeConverted)
                        {
                            AddRecurse(gameOjectWorld.EntityManager, convert.transform, toBeDetached, toBeInjectd);
                        }

                        foreach (var convert in toBeConverted)
                        {
                            conversionRoots.Add(convert.gameObject);
                            toBeDetached.Remove(convert.transform);
                        }

                        //GameObjectConversionUtility.Conver(gameOjectWorld);//抄不下去了，internal的
                    }
                }
            }
            catch(Exception ex)
            {

            }
            finally
            {

            }
        }
    }
}
